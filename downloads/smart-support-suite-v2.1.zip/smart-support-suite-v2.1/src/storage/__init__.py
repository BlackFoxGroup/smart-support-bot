"""Local persistence helpers."""
