from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from src.knowledge.source_catalog import sftp_conn
from src.knowledge.source_catalog.sftp_conn import push_catalog_json_to_bot
from src.ai.safety import bounded_ask_timeout, bounded_ask_tokens
from src.config import KNOWLEDGE_ROOT
from src.manager.app import _html
from src.manager.ai_store import (
    load_ai_settings,
    save_ai_settings,
    set_ai_connection_state,
)
from src.operation_control import (
    OperationStopped,
    begin_operation,
    raise_if_stopped,
    stop_all_operations,
)
from src.knowledge.source_catalog.analyze import analyze_and_send
from src.knowledge.source_catalog.queue import cancel_active_uploads, load_upload_state
from src.knowledge.source_catalog.store import (
    load_global_queue,
    load_media_index,
    save_global_queue,
    save_media_index,
)
from src.knowledge.catalog_rag import build_catalog_units
from src.knowledge.product_catalogs import (
    load_product_catalogs,
    update_product_fields,
)


class _RemoteHandle:
    def __init__(self, files: dict[str, bytes], path: str, mode: str) -> None:
        self.files = files
        self.path = path
        self.mode = mode
        self.buffer = bytearray(files.get(path, b""))

    def __enter__(self):
        return self

    def __exit__(self, *_args) -> None:
        if "w" in self.mode:
            self.files[self.path] = bytes(self.buffer)

    def read(self):
        return bytes(self.buffer)

    def write(self, value: bytes | str) -> None:
        if isinstance(value, str):
            value = value.encode("utf-8")
        self.buffer = bytearray(value)


class _Sftp:
    def __init__(self, files: dict[str, bytes]) -> None:
        self.files = files
        self.dirs = {"/", "/srv", "/srv/bot"}

    def open(self, path: str, mode: str):
        if "r" in mode and path not in self.files:
            raise FileNotFoundError(path)
        return _RemoteHandle(self.files, path, mode)

    def stat(self, path: str):
        if path not in self.dirs and path not in self.files:
            raise FileNotFoundError(path)
        return object()

    def mkdir(self, path: str) -> None:
        self.dirs.add(path)

    def put(self, local: str, remote: str, callback=None) -> None:
        payload = Path(local).read_bytes()
        self.files[remote] = payload
        if callback:
            callback(len(payload), len(payload))

    def posix_rename(self, source: str, target: str) -> None:
        self.files[target] = self.files.pop(source)

    def close(self) -> None:
        return None


class _Channel:
    @staticmethod
    def recv_exit_status() -> int:
        return 0


class _Stream:
    channel = _Channel()

    def __init__(self, payload: bytes = b"") -> None:
        self.payload = payload

    def read(self) -> bytes:
        return self.payload


class _Client:
    def __init__(self) -> None:
        self.command = ""

    def exec_command(self, command: str, timeout: int = 0):
        self.command = command
        active = b"active\n" if "is-active" in command else b""
        return None, _Stream(active), _Stream()


class Manager21Tests(unittest.TestCase):
    def test_manager_script_is_valid_for_send_button(self) -> None:
        page = _html("<button class='send-one'>send</button>", lang="en").decode()
        self.assertIn("document.querySelectorAll('.send-one')", page)
        self.assertNotIn("let j={{}}", page)
        self.assertIn("e.target.closest('a.zoom')", page)
        self.assertIn("form.busy-form", page)

    def test_bot_ai_request_has_bounded_latency_and_output(self) -> None:
        settings = SimpleNamespace(ai_timeout_seconds=60, ai_max_tokens=4096)
        self.assertEqual(bounded_ask_timeout(settings.ai_timeout_seconds), 20.0)
        self.assertEqual(bounded_ask_tokens(settings.ai_max_tokens), 2048)

    def test_manual_feature_sends_without_slow_ai_analysis(self) -> None:
        with (
            patch(
                "src.knowledge.source_catalog.analyze.analyze_media",
                side_effect=AssertionError("AI analysis must be skipped"),
            ),
            patch(
                "src.knowledge.source_catalog.queue.send_mapped_media_to_catalog",
                return_value={"ok": True},
            ) as send,
        ):
            out = analyze_and_send(
                Path("project"),
                Path("knowledge"),
                Path("data"),
                "product",
                "media",
                feature_id="feature-1",
            )
        self.assertTrue(out["ok"])
        self.assertTrue(out["analysis_skipped"])
        send.assert_called_once()

    def test_catalog_json_is_atomically_published_and_bot_reloaded(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            knowledge = root / "knowledge"
            catalog = knowledge / "product_catalogs" / "demo.json"
            catalog.parent.mkdir(parents=True)
            catalog.write_text('{"product_id":"demo","catalog_enabled":true}', encoding="utf-8")
            files: dict[str, bytes] = {}
            sftp = _Sftp(files)
            client = _Client()
            with (
                patch.object(sftp_conn, "_live_sftp", return_value=(sftp, {})),
                patch.object(sftp_conn, "remote_install_root", return_value="/srv/bot"),
                patch.dict(sftp_conn._SESS, {"client": client, "sftp": sftp}),
            ):
                out = push_catalog_json_to_bot(
                    root / "data", knowledge, "demo", restart=True
                )
            self.assertTrue(out["ok"])
            self.assertEqual(
                files["/srv/bot/products/demo/catalog.json"],
                catalog.read_bytes(),
            )
            self.assertNotIn(
                "/srv/bot/products/demo/catalog.json.uploading", files
            )
            self.assertIn("systemctl restart smart-support-bot.service", client.command)

    def test_unified_install_path_enables_local_catalog_discovery(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "smart-support"
            knowledge = root / "knowledge"
            catalog = knowledge / "product_catalogs" / "demo.json"
            catalog.parent.mkdir(parents=True)
            catalog.write_text('{"product_id":"demo"}', encoding="utf-8")
            with (
                patch.dict(
                    os.environ,
                    {
                        "MANAGER_LOCAL_BOT": "1",
                        "BOT_REMOTE_ROOT": str(root),
                        "MANAGER_CONFIG_DIR": str(root / "data"),
                    },
                ),
                patch.object(sftp_conn, "_restart_local_bot", return_value={"ok": True}),
            ):
                self.assertTrue(sftp_conn.session_status()["connected"])
                sftp_conn.disconnect_session()
                self.assertFalse(sftp_conn.session_status()["connected"])
                self.assertTrue(sftp_conn.connect_session(root / "data")["ok"])
                self.assertTrue(sftp_conn.session_status()["connected"])
                settings = sftp_conn.load_sftp_settings(root / "data")
                self.assertEqual(settings["remote_bot_root"], str(root))
                out = push_catalog_json_to_bot(
                    root / "data", knowledge, "demo", restart=True
                )
            self.assertTrue(out["ok"])
            self.assertTrue(out["local"])

    def test_linux_installer_uses_one_default_root(self) -> None:
        root = Path(__file__).resolve().parents[1]
        script = (root / "deploy" / "install-manager.sh").read_text(encoding="utf-8")
        installer = (root / "src" / "manager" / "install_bot.py").read_text(
            encoding="utf-8"
        )
        self.assertIn('MANAGER_INSTALL_DIR:-/opt/smart-support', script)
        self.assertIn('Environment="MANAGER_LOCAL_BOT=1"', script)
        self.assertIn('REMOTE_ROOT = "/opt/smart-support"', installer)
        self.assertNotIn('"/opt/telegram-bot"', installer)

    def test_ai_uses_only_enabled_product_catalogs(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            knowledge = Path(tmp)
            folder = knowledge / "product_catalogs"
            folder.mkdir()
            (folder / "enabled.json").write_text(
                '{"product_id":"enabled","catalog_enabled":true,"title":{"en":"Enabled"}}',
                encoding="utf-8",
            )
            (folder / "disabled.json").write_text(
                '{"product_id":"disabled","catalog_enabled":false,"title":{"en":"Disabled"}}',
                encoding="utf-8",
            )
            load_product_catalogs(knowledge)
            ids = {
                unit.product_id
                for unit in build_catalog_units(lang="en")
                if unit.kind == "product"
            }
            self.assertIn("enabled", ids)
            self.assertNotIn("disabled", ids)
            update_product_fields(knowledge, "disabled", catalog_enabled=True)
            ids = {
                unit.product_id
                for unit in build_catalog_units(lang="en")
                if unit.kind == "product"
            }
            self.assertIn("disabled", ids)
        load_product_catalogs(KNOWLEDGE_ROOT)

    def test_legacy_catalog_and_media_migrate_to_fixed_product_folder(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            knowledge = root / "knowledge"
            legacy_catalog = knowledge / "product_catalogs" / "demo.json"
            legacy_catalog.parent.mkdir(parents=True)
            legacy_catalog.write_text(
                '{"product_id":"demo","media":[{"path":"media/catalogs/demo/a.png"}]}',
                encoding="utf-8",
            )
            legacy_media = root / "media" / "catalogs" / "demo"
            legacy_media.mkdir(parents=True)
            (legacy_media / "a.png").write_bytes(b"image")

            load_product_catalogs(knowledge)

            catalog = root / "products" / "demo" / "catalog.json"
            self.assertTrue(catalog.is_file())
            self.assertTrue((root / "products" / "demo" / "media" / "a.png").is_file())
            self.assertIn("products/demo/media/a.png", catalog.read_text(encoding="utf-8"))

    def test_product_server_path_is_read_only_in_manager_ui(self) -> None:
        app_source = (
            Path(__file__).resolve().parents[1] / "src" / "manager" / "app.py"
        ).read_text(encoding="utf-8")
        self.assertNotIn("name='server_media'", app_source)
        self.assertIn("t(lang,'auto_catalog')", app_source)

    def test_stop_all_cancels_existing_work_but_allows_new_work(self) -> None:
        begin_operation()
        stop_all_operations()
        with self.assertRaises(OperationStopped):
            raise_if_stopped()
        begin_operation()
        raise_if_stopped()

    def test_stop_all_clears_persisted_upload_state(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            data_dir = Path(td)
            save_global_queue(
                data_dir,
                [{"job_id": "j1", "product_id": "p1", "media_id": "m1", "status": "UPLOADING"}],
            )
            save_media_index(data_dir, "p1", {"items": [{"media_id": "m1", "status": "UPLOADING"}]})
            from src.knowledge.source_catalog.queue import set_upload_state

            set_upload_state(data_dir, busy=True, filename="stale.jpg")
            self.assertEqual(cancel_active_uploads(data_dir), 1)
            self.assertEqual(load_global_queue(data_dir)[0]["status"], "CANCELLED")
            self.assertEqual(load_media_index(data_dir, "p1")["items"][0]["status"], "LOCAL_ONLY")
            self.assertFalse(load_upload_state(data_dir)["busy"])

    def test_automatic_catalog_controls_use_requested_order(self) -> None:
        app_source = (Path(__file__).parents[1] / "src" / "manager" / "app.py").read_text(encoding="utf-8")
        names = [
            "/run/auto-catalog",
            "/run/save-catalog",
            "/run/scan",
            "/run/map",
            "/run/send-media",
            "/run/activate",
            "/run/rollback",
        ]
        positions = [app_source.index(name) for name in names]
        self.assertEqual(positions, sorted(positions))

    def test_suite_installer_prepares_bot_without_starting_it(self) -> None:
        from src.manager import install_bot

        client = SimpleNamespace(close=lambda: None)
        with (
            patch.object(install_bot, "_connect", return_value=client),
            patch.object(install_bot, "_upload_suite", return_value=12),
            patch.object(install_bot, "_write_env"),
            patch.object(install_bot, "_execute", return_value=(True, "")) as execute,
        ):
            result = install_bot.install_telegram_bot(
                local_path="suite",
                host="server.test",
                port="22",
                username="root",
                password="password",
                bot_token="token",
            )
        command = execute.call_args.args[1]
        self.assertTrue(result["ok"])
        self.assertIn("/opt/smart-support", command)
        self.assertIn("smart-support-bot.service", command)
        self.assertNotIn("enable --now", command)

    def test_suite_installer_prepares_expert_without_starting_it(self) -> None:
        from src.manager import install_bot

        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "src" / "manager").mkdir(parents=True)
            (root / "src" / "manager" / "app.py").write_text("", encoding="utf-8")
            client = SimpleNamespace(close=lambda: None)
            with (
                patch.object(install_bot, "_connect", return_value=client),
                patch.object(install_bot, "_upload_suite", return_value=15),
                patch.object(install_bot, "_execute", return_value=(True, "")) as execute,
            ):
                result = install_bot.install_expert(
                    local_path=str(root),
                    host="server.test",
                    port="22",
                    username="root",
                    password="password",
                )
        command = execute.call_args.args[1]
        self.assertTrue(result["ok"])
        self.assertIn("smart-support-manager.service", command)
        self.assertIn('Environment="MANAGER_PORT=8766"', command)
        self.assertNotIn("enable --now", command)

    def test_suite_activation_starts_and_checks_both_services(self) -> None:
        from src.manager import install_bot

        client = SimpleNamespace(close=lambda: None)
        with (
            patch.object(install_bot, "_connect", return_value=client),
            patch.object(install_bot, "_execute", return_value=(True, "bot=active\nexpert=active")) as execute,
        ):
            result = install_bot.activate_bot_and_expert(
                host="server.test",
                port="22",
                username="root",
                password="password",
            )
        command = execute.call_args.args[1]
        self.assertEqual(result, {"ok": True, "bot": "active", "expert": "active"})
        self.assertIn("enable --now smart-support-bot.service smart-support-manager.service", command)
        self.assertIn("systemctl is-active smart-support-bot.service", command)
        self.assertIn("systemctl is-active smart-support-manager.service", command)

    def test_install_page_has_fixed_path_and_three_stages(self) -> None:
        source = (Path(__file__).parents[1] / "src" / "manager" / "app.py").read_text(encoding="utf-8")
        controls = ["/api/install-bot", "/api/install-expert", "/api/activate-suite"]
        positions = [source.index(f'formaction="{path}"') for path in controls]
        self.assertEqual(positions, sorted(positions))
        self.assertNotIn('name="remote_dir"', source)
        self.assertNotIn('name="start_cmd"', source)
        self.assertNotIn('name="extra_env"', source)
        self.assertNotIn('name="extra_pip"', source)
        self.assertIn("_path_pick('local_path',str(PROJECT_ROOT),'local_path',lang)", source)
        self.assertIn('name="bot_mode"', source)
        self.assertIn('name="webhook_url"', source)
        self.assertIn('<code class="readonly-path">/opt/smart-support</code>', source)
        self.assertIn('class="install-actions"', source)
        self.assertIn('aria-live="polite"', source)

    def test_webhook_install_writes_mode_and_secret(self) -> None:
        from src.manager import install_bot

        files: dict[str, bytes] = {}
        sftp = _Sftp(files)
        client = SimpleNamespace(open_sftp=lambda: sftp)
        install_bot._write_env(
            client,
            token="telegram-token",
            extra_env="",
            bot_mode="webhook",
            webhook_url="https://bot.example.com",
            webhook_port="8080",
        )
        env = files["/opt/smart-support/.env"].decode()
        self.assertIn("BOT_UPDATE_MODE=webhook", env)
        self.assertIn("BOT_WEBHOOK_URL=https://bot.example.com/telegram/webhook", env)
        self.assertIn("BOT_WEBHOOK_SECRET=", env)

    def test_bot_entrypoint_supports_polling_and_webhook(self) -> None:
        source = (Path(__file__).parents[1] / "src" / "main.py").read_text(encoding="utf-8")
        self.assertIn('update_mode == "webhook"', source)
        self.assertIn("SimpleRequestHandler", source)
        self.assertIn("dp.start_polling", source)

    def test_desktop_launcher_is_hidden_and_closes_with_browser(self) -> None:
        root = Path(__file__).parents[1]
        batch = (root / "Start-Smart-Support-Manager-v2.bat").read_text(encoding="utf-8")
        app = (root / "src" / "manager" / "app.py").read_text(encoding="utf-8")
        self.assertIn("MANAGER_DESKTOP_SESSION=1", batch)
        self.assertIn("pythonw.exe", batch)
        self.assertIn("/api/desktop-heartbeat", app)
        self.assertIn("/api/desktop-close", app)
        self.assertIn("pagehide", app)

    def test_one_command_installer_covers_local_and_remote_setup(self) -> None:
        root = Path(__file__).parents[1]
        script = (root / "deploy" / "install-suite.ps1").read_text(encoding="utf-8")
        readme = (root / "README.md").read_text(encoding="utf-8")
        self.assertIn('%LOCALAPPDATA%\\SmartSupport', readme)
        self.assertIn("install_telegram_bot", script)
        self.assertIn("install_expert", script)
        self.assertIn("activate_bot_and_expert", script)
        self.assertIn('Start-Process "http://127.0.0.1:8766"', script)
        self.assertIn("deploy/install-suite.ps1 | iex", readme)

    def test_public_expert_icon_is_served_by_manager(self) -> None:
        root = Path(__file__).parents[1]
        source = (root / "src" / "manager" / "app.py").read_text(encoding="utf-8")
        self.assertTrue((root / "docs" / "assets" / "expert-icon.jpg").is_file())
        self.assertIn('path == "/expert-icon"', source)
        self.assertIn('src="/expert-icon"', source)

    def test_ai_and_server_settings_persist_in_manager_directory(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            config_dir = root / "manager-data"
            (root / "bot").mkdir()
            with patch.dict(os.environ, {"MANAGER_CONFIG_DIR": str(config_dir)}):
                sftp_conn.save_sftp_settings(
                    root / "bot-data",
                    {
                        "host": "server.test",
                        "port": 2222,
                        "username": "admin",
                        "auth_method": "password",
                        "key_path": "",
                        "remote_media_path": "/srv/media",
                        "remote_bot_root": "/srv/bot",
                    },
                    password="server-secret",
                )
                save_ai_settings(
                    root / "bot",
                    root / "bot-data",
                    base_url="https://ai.test/v1",
                    model="model-1",
                    api_key="api-secret",
                )
                server = sftp_conn.load_sftp_settings(root / "bot-data")
                ai = load_ai_settings(root / "bot", root / "bot-data")
                set_ai_connection_state(root / "bot", root / "bot-data", connected=True)
                connected_ai = load_ai_settings(root / "bot", root / "bot-data")
            self.assertEqual(server["host"], "server.test")
            self.assertEqual(server["remote_bot_root"], "/srv/bot")
            self.assertTrue(server["has_password"])
            self.assertEqual(ai["model"], "model-1")
            self.assertEqual(ai["api_key"], "api-secret")
            self.assertTrue(connected_ai["connected"])
            self.assertEqual(connected_ai["api_key"], "api-secret")
            self.assertTrue((config_dir / "sftp.json").is_file())
            self.assertTrue((config_dir / "ai.json").is_file())

    def test_remote_ai_merge_preserves_other_env_keys_and_restarts(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            data_dir = Path(tmp)
            files = {"/srv/bot/.env": b"TELEGRAM_BOT_TOKEN=keep\nAI_MODEL=old\n"}
            client = _Client()
            with (
                patch.object(sftp_conn, "_live_sftp", return_value=(_Sftp(files), {})),
                patch.object(sftp_conn, "remote_install_root", return_value="/srv/bot"),
                patch.dict(sftp_conn._SESS, {"client": client, "sftp": object(), "host": "server.test"}),
            ):
                result = sftp_conn.sync_remote_ai(
                    data_dir,
                    base_url="https://ai.test/v1",
                    model="new-model",
                    api_key="new-key",
                )
            env_text = files["/srv/bot/.env"].decode()
            self.assertTrue(result["ok"])
            self.assertIn("TELEGRAM_BOT_TOKEN=keep", env_text)
            self.assertIn("AI_MODEL=new-model", env_text)
            self.assertIn("AI_API_KEY=new-key", env_text)
            self.assertEqual(client.command, "systemctl restart smart-support-bot.service")


if __name__ == "__main__":
    unittest.main()
