"""Local persistence helpers."""
