# AI memory for telegram-bot-expert-installer

This file survives agent/API changes. Ask AI must read it first.
Behavior rules (from Chat with AI) override the default short/dry tone.
Catalog teaching is only about catalog photos/facts and how to teach users from the catalog.
If a learned Q matches the user, use that answer. Else use Operator facts, then catalog teaching, then the catalog.

## Behavior rules
<!-- BEGIN BEHAVIOR -->
- (none yet)
<!-- END BEHAVIOR -->

## Operator facts
<!-- BEGIN FACTS -->
- (none yet)
<!-- END FACTS -->

## Catalog teaching
<!-- BEGIN CATALOG -->
Catalog teaching for Telegram Bot Expert Installer ONLY.
When the user asks how to use a section, answer as a tutor: what it is, what it is for, ordered steps, one tip.
Use the howto blocks below. Do not invent steps not listed here.

## languages — زبان‌های پشتیبانی‌شده / Supported languages
هدف طراحی: بدانی Expert Installer با چهار زبان فارسی، انگلیسی، روسی و چینی کار می‌کند.
عملکرد: از منوی زبان یا تنظیمات زبان یکی را انتخاب کن؛ متن‌های داشبورد و بخش‌ها همان لحظه عوض می‌شوند. اگر زبان اشتباه ماند یک‌بار برنامه را ببند و دوباره باز کن.
Design goal: Know Expert Installer supports Persian, English, Russian, and Chinese.
Behavior: Pick a language from the language menu or settings; dashboard and section text switch right away. If it sticks, close and reopen the app once.

## dashboard — داشبورد / Dashboard
هدف طراحی: از یک صفحه، وضعیت ربات و میانبر کارهای اصلی را ببینی.
عملکرد: Expert Installer را باز کن تا داشبورد بیاید. از همین‌جا به نصب، بررسی سلامت، بکاپ، لاگ و حذف نصب برو. قبل از کار جدید، یک نگاه به وضعیت کلی ربات بینداز.
Design goal: See bot status and shortcuts to main tasks on one screen.
Behavior: Open Expert Installer to land on the dashboard. From here open install, health check, backup, logs, or uninstall. Glance at overall status before starting a new change.

## install_bot — نصب ربات / Install bot
هدف طراحی: ربات تلگرام را بدون کار دستی روی لینوکس خام بالا بیاوری.
عملکرد: کلید نصب ربات را بزن، مسیر/تنظیمات خواسته‌شده را پر کن و مراحل را تا پایان دنبال کن. بعد از اتمام، از بررسی سلامت مطمئن شو سرویس بالا است؛ اگر گیر کرد لاگ همان مرحله را بخوان.
Design goal: Bring up the Telegram bot without raw Linux handwork.
Behavior: Tap Install bot, fill the requested path/settings, and finish every step. Then use Health check to confirm the service is up; if it stalls, read the log for that step.

## health_check — بررسی سلامت / Health check
هدف طراحی: بفهمی سرویس ربات سالم است یا کجا خطا دارد.
عملکرد: بررسی سلامت را اجرا کن و نتیجه OK/هشدار/خطا را بخوان. اگر خطا بود همان پیام را نگه دار، بعد به لاگ‌ها سر بزن یا نصب را دوباره چک کن؛ برای سوال دقیق‌تر «سوال از AI» را بزن.
Design goal: Tell whether the bot service is healthy or where it fails.
Behavior: Run Health check and read OK / warning / error. Keep the error text, then open Logs or recheck Install; for a guided answer, tap Ask AI.

## backup — بکاپ / Backup
هدف طراحی: قبل از تغییر بزرگ، از تنظیمات و داده ربات نسخه داشته باشی.
عملکرد: بکاپ را بزن و فایل/مسیر ذخیره‌شده را یادداشت کن. قبل از آپدیت، حذف نصب یا دستکاری تنظیمات حتماً یک بکاپ تازه بگیر؛ برای برگرداندن، همان بکاپ را از همین بخش بازیابی کن.
Design goal: Keep a copy of bot settings/data before big changes.
Behavior: Run Backup and note where the file was saved. Take a fresh backup before update, uninstall, or config edits; restore that backup from this same section when needed.

## logs — لاگ‌ها / Logs
هدف طراحی: علت خطا را از لاگ واقعی ببینی، نه با حدس.
عملکرد: لاگ‌ها را باز کن و آخرین خطوط مربوط به زمان خطا را بخوان. اگر برای پشتیبانی می‌فرستی، همان بازه زمانی را کپی کن؛ برای فهمیدن معنی خطا، متن را در «سوال از AI» بپرس.
Design goal: Find the real cause from logs, not guesses.
Behavior: Open Logs and read the latest lines around the failure time. If you send them to support, copy that time window; to understand an error line, paste it into Ask AI.

## uninstall — حذف نصب / Uninstall
هدف طراحی: ربات را تمیز از سیستم برداری تا سرویس و فایل‌های نصب نمانند.
عملکرد: اول از بخش بکاپ یک نسخه بگیر، بعد حذف نصب را شروع کن و مراحل را تا تأیید نهایی برو. پس از حذف، یک‌بار بررسی سلامت/وضعیت سرویس را چک کن که چیزی باقی نمانده باشد.
Design goal: Remove the bot cleanly so service and install files are gone.
Behavior: Take a Backup first, then start Uninstall and finish every confirm step. Afterward, check Health/status once to be sure nothing is left running.

## contact — تماس Expert Installer / Expert Installer contact
هدف طراحی: راه ارتباط با تیم پشتیبانی Expert را دم دست داشته باشی.
عملکرد: از این صفحه کانال‌های تماس را باز کن. برای پرسش‌های بیشتر درباره همین محصول از گزینه «سوال از AI» استفاده کنید.
Design goal: Keep Expert support contact paths handy.
Behavior: Open the contact channels from this screen. For more questions about this product, use Ask AI.
<!-- END CATALOG -->

## Learned user answers
<!-- BEGIN LEARNED -->
### Q: ربات چه جوری نصب کنم
A: نصب ربات
هدف طراحی: ربات تلگرام را بدون کار دستی روی لینوکس خام بالا بیاوری.
عملکرد: کلید نصب ربات را بزن، مسیر/تنظیمات خواسته‌شده را پر کن و مراحل را تا پایان دنبال کن. بعد از اتمام، از بررسی سلامت مطمئن شو سرویس بالا است؛ اگر گیر کرد لاگ همان مرحله را بخوان.

### Q: How do I install the bot?
A: Install bot

Design goal: Bring up the Telegram bot without raw Linux handwork.
Behavior: Tap Install bot, fill the requested path/settings, and finish every step. Then use Health check to confirm the service is up; if it stalls, read the log for that step.
<!-- END LEARNED -->
