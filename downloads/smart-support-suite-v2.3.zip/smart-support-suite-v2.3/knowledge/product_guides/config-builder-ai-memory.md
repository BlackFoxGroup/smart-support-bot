# AI memory for config-builder

This file survives agent/API changes. Ask AI must read it first.
Behavior rules (from Chat with AI) override the default short/dry tone.
Catalog teaching is only about catalog photos/facts and how to teach users from the catalog.
If a learned Q matches the user, use that answer. Else use Operator facts, then catalog teaching, then the catalog.

## Behavior rules
<!-- BEGIN BEHAVIOR -->
- (none yet)
<!-- END BEHAVIOR -->

## Operator facts
<!-- BEGIN FACTS -->
- (none yet)
<!-- END FACTS -->

## Catalog teaching
<!-- BEGIN CATALOG -->
(none yet)
<!-- END CATALOG -->

## Learned user answers
<!-- BEGIN LEARNED -->
### Q: لیست
A: بخش لیست در Config Builder محلی برای مدیریت کانفیگ‌های ساخته‌شده شماست.
کاربرد آن این است که بتوانید همه کانفیگ‌هایی که تا الان ساخته‌اید را در یک جا ببینید و در صورت نیاز آن‌ها را ویرایش یا حذف کنید.
برای استفاده از آن، وارد بخش لیست شوید، کانفیگ موردنظر را از میان موارد ساخته‌شده پیدا کنید، سپس آن را مشاهده، ویرایش یا حذف کنید.
نکته مفید این است که قبل از حذف هر کانفیگ مطمئن شوید دیگر به آن نیازی ندارید، چون پس از حذف باید دوباره آن را بسازید.

### Q: عکس   بخش تنظیمات
A: بخش تنظیمات در Config Builder محلی برای تغییر زبان برنامه، دریافت آخرین نسخه نرم‌افزار از سرور رسمی Black Fox و مشاهده جزئیات کارهای انجام‌شده در قسمت Log است.

برای استفاده از آن، وارد بخش تنظیمات شوید، زبان موردنظر خود را انتخاب کنید، در صورت نیاز آخرین نسخه را از سرور رسمی دریافت کنید و برای بررسی فعالیت‌های برنامه به قسمت Log مراجعه کنید.

نکته مفید این است که اگر برنامه رفتار غیرمنتظرهای داشت، ابتدا Log را بررسی کنید تا جزئیات دقیق انجام‌شده را ببینید.

تصویر آموزشی بخش تنظیمات برای شما ارسال می‌شود.
<!-- END LEARNED -->
