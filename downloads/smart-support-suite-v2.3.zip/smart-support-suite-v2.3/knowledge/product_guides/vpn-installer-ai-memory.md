# AI memory for vpn-installer

This file survives agent/API changes. Ask AI must read it first.
Behavior rules (from Chat with AI) override the default short/dry tone.
Catalog teaching is only about catalog photos/facts and how to teach users from the catalog.
If a learned Q matches the user, use that answer. Else use Operator facts, then catalog teaching, then the catalog.

## Behavior rules
<!-- BEGIN BEHAVIOR -->
- (none yet)
<!-- END BEHAVIOR -->

## Operator facts
<!-- BEGIN FACTS -->
- (none yet)
<!-- END FACTS -->

## Catalog teaching
<!-- BEGIN CATALOG -->
(none yet)
<!-- END CATALOG -->

## Learned user answers
<!-- BEGIN LEARNED -->
### Q: در باره مد پایه توضیح بده
A: مد پایه (Basic Mode)
مد Basic: شروع ساده؛ نصب پنل رایگان برای تست؛ برای Exit و پیکربندی لایسنس لازم است.
هدف طراحی: مد Basic یکی از سه حالت Basic، Pro و AI Pro در VPS to VPN by Black Fox Group است و برای شروع ساده طراحی شده؛ ساده‌ترین حالت برای داشتن یک پنل VPN شخصی است.
عملکرد: نصب پنل در این مد رایگان است و برای تست و آشنایی با برنامه است. در زمان اتصال سرور خروجی و پیکربندی باید لایسنس مد کاری مورد نظرت را تهیه کنی.

### Q: چه جوری سرور خروجی ثبت کنم؟
A: ثبت سرور خروجی (Exit Server) در برنامه VPS to VPN by Black Fox Group یعنی اینکه مشخص می‌کنی ترافیک از کدام سرور خارج شود تا مسیر درست کار کند.

مراحل ثبت:
۱. اول مطمئن شو سرور مرکزی (Central) آماده است و لایسنس مد کاری فعال داری.
۲. گزینه Add Exit را باز کن.
۳. آی‌پی یا دامنه و مشخصات SSH سرور خروجی را وارد کن.
۴. مراحل را تا ذخیره کامل جلو ببر تا سرور به لیست اضافه شود.

نکته‌ها:
- حداکثر ۶ سرور خروجی می‌توانی داشته باشی؛ اگر جا نداری، اول یکی را حذف کن بعد جدید بزن.
- اشتباه رایج: ثبت Exit قبل از راه‌اندازی سرور مرکزی، یا تلاش بدون لایسنس است.
- برای دیدن ارتباط‌ها بعد از ثبت، بخش Mesh یا Connection manager را باز کن.
<!-- END LEARNED -->
